import logo from './logo.svg'; 
import './App.css';

import ListEmployee from './Components/ListEmployee';
import Login from './Components/Login';
import LoginManager from './Components/LoginManager';
import LeaveDate from './Components/LeaveApplication';
import LeaveListComponent from './Components/LeaveList';
import {Routes,Route,Link} from 'react-router-dom';

import GetAllLeaveApp from './Components/GetAllLeaveApp';

import ListManager from './Components/Manager';

import AddLeave from './Components/LeaveCreate';

import DashBoard from './Components/DashBoard.jsx';
import Logout from './Components/Logout';

// import Approveordenyleave from './Components/ApproveOrDenyLeave';

function App() {
  return (
    <div className="App">
      <h1>Leave Management System</h1>
      {/* <Link to={'registration'}>Registration </Link> */}
{/*       
      <Link to={'Login'}>Log_in</Link> */}
      {/* <Link to={'/listEmployee'}>ListEmployee </Link>
      <Link to={'/manager'}>Manager </Link>
      <Link to={'/leave'}> Leave_Datails  </Link> 
      
      
      
      

  <Link to={'/addleave'}>Add_Leave </Link>*/}
      {/* <Link to={'/Logout'}>Log_Out </Link>  */}
      {/* <Link to={'/ApproveOrDenyLeave'}>Approveordenyleave</Link> */}
      <Link to={'/LoginManager'}>LoginManager</Link>
      {/* <Link to={'/LoginManager'}>LoginManager</Link> */}


    <Routes>
      
      <Route path='/' element={<Login/>}></Route>
      <Route path='/listEmployee' element={<ListEmployee/>}></Route>
      <Route path='/manager' element={<ListManager/>}></Route>
      <Route path='/leave' element={<LeaveDate/>}></Route> 
      <Route path='/DashBoard' element={<DashBoard/>}></Route>
      <Route path='/LoginManager' element={<LoginManager/>}></Route>
      <Route path='/LeaveListComponent' element={<LeaveListComponent/>}></Route>
      <Route path='/GetAllLeaveApp' element={<GetAllLeaveApp/>}></Route>
      
      <Route path='/addleave' element={<AddLeave/>}></Route>
      <Route path='/Logout' element={<Logout/>}></Route>
      {/* <Route path='/ApproveOrDenyLeave' element={<Approveordenyleave/>}></Route> */}

      
    </Routes>
    </div>
  );
}

export default App;

