import React, { Component } from 'react'
import axios from 'axios';

export default class ShowLvDetailsById extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      Leave_A:[],
      leaveId:''
    }
    
  }
  DisplayLvById()
  {
    let leaveId= this.state.leaveId;
    let url='http://localhost:21808/api/Leaves'+leaveId;
    axios.get(url).then(Response=>
        {
            this.setState({Leave_A:Response.data})
        }).catch(error=>{
            console.warn(error);
            alert(error);
        })
  }
  componentDidMount()
  {
        this.DisplayLvById();
  } 
    render() {
        const{Leave_A}=this.state;
    return (
      <div>ShowLvDetailsById


<table>
            <tr>
                <th>Leave Id</th>
                <th>NoOfDays</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Leave Type</th>
                <th>Status</th>
                <th>Reason</th>
                {/* <th>ManagerComments</th> */}
                
            </tr>
            {
                 Leave_A.map(c=>
                    <tr><th>{c.leaveId}</th>
                    <th>{c.noOfDays}</th>
                    <th>{c.startDate}</th>
                    <th>{c.endDate}</th>
                    <th>{c.leaveType}</th>
                    <th>{c.status}</th>
                    <th>{c.reason}</th>
                    {/* <th>{c.managerComments}</th> */}
                    </tr>
                    )
            }
            <label>Enter the Leave Id</label>
        <input type="text" name="leaveId" onChange={(e)=>this.handlechange({leaveId:e.target.value})}></input>
    <button onClick={this.DisplayLvById}>Click</button>
        </table>
      </div>
    )
  }
}
