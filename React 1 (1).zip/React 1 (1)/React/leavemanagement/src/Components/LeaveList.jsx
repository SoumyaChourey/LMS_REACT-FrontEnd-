import React from "react"; 
import { Route } from "react-router-dom";
import axios from "axios";
import LeaveOperations from "../Services/LeaveOperations";
import DashBoard from "./DashBoard";
// import AddLeave from "./AddLeave";
import { useNavigate,Redirect } from "react-router-dom";


class LeaveListComponent extends React.Component
{

    constructor(props)
    {
        super(props)
        this.state={
            leave:[]
        }
    }
    

    componentDidMount()

    {
        LeaveOperations.getLeave().then((e)=>{
          this.setState({leave:e.data});
        })

    }
    
    approvehandler()
    {
        console.log('approvehandler called');
        this.setState({status:'Approved'});
        console.log(this.state.status);
        console.log(localStorage.status);
        console.log(localStorage.leaveId);
        localStorage.setItem('status','Approved');
        this.updateaction();
    }
    updateaction=()=>
    {
        console.log('updateactioncalls');
        console.log(localStorage.getItem('leaveid'));
        console.log(localStorage.getItem('status'));

        axios.put('http://localhost:21808/api/Leaves/'+localStorage.getItem('leaveid')+'&status='+localStorage.getItem('status'))
     //   +'&comment='+this.state.comments).
        .then((res)=>{
            if(res.data==='Success')
            {
                window.location='/DashBoard';
            }
            else
            {
                alert('Error occured');
            }
        })
    }
    render()
    {
        return(
            <div>
                <h2 className="text-center">Leave Application List</h2>
                <br></br>
                <br></br>
                <div className="row">
                    <table className="table table-striped table-bordered">

                    <thead>
                        <tr>
                            <th>Id</th>
                            {/* <th>Leave Status</th> */}
                            <th>No Of Days</th>
                            <th>Type of Leave</th>
                            <th>Start Date</th>
                            <th>End date</th>
                            <th>Status</th>
                            <th>Reason</th>
                            {/* <th>Manager Comments</th> */}

                        </tr>
                    </thead>  

                        <tbody>
                        {
                             this.state.leave.map(
                                  (l)=>
                                    <tr key ={l.leaveId}>
                                    <td>{l.leaveId}</td>
                                    <td>{l.noOfDays}</td>
                                    <td>{l.leaveType}</td>
                                    <td>{l.startDate}</td>
                                    <td>{l.endDate}</td>  
                                    <td>{l.status}</td>
                                    <td>{l.reason}</td>
                                    {/* <td>{l.managerComments}</td> */}

                                </tr>
) 
                         }
                     </tbody>
                     </table>
                     {/* <div className="btn btn-primary" ><h2 onClick={()=>navigate('/AddLeave')}>New Application  </h2></div> */}
                     {/* <button type="submit" className="btn btn-primary">New Application</button> */}
                     <button className="btn btn-success" onClick={()=>this.approvehandler()}>Approve</button>
                <button className="btn btn-Danger" onClick={()=>this.denyhandler()}>Deny</button>
                <button className="btn btn-primary" onClick={()=>this.cancel()}>Cancel</button>
                 </div>
                 </div>
         )
    }
}

export default LeaveListComponent;


 

